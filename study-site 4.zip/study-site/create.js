/* The Study Room: From Your Notes
   Paste notes -> review suggested flashcards, quiz questions and a summary -> save
   them into the Flashcards, Quizzes and Summaries pages (all linked together).
   Uses CardGenerator from card-generator.js. Everything stays in this browser. */
(() => {
  'use strict';

  const FLASHCARD_KEY = 'studyroom.flashcards.v1';
  const QUIZ_KEY = 'studyroom.quizzes.v1';
  const SUMMARY_KEY = 'studyroom.summaries.v1';
  const DRAFT_KEY = 'studyroom.notes-draft'; // sessionStorage: keeps your pasted notes if you leave the page

  const $ = (id) => document.getElementById(id);
  const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36);
  const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
  const readJSON = (key) => { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) { return null; } };
  const G = window.CardGenerator;

  function h(tag, props = {}, ...kids) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    }
    kids.flat(Infinity).forEach((c) => { if (c != null && c !== false) node.append(c); });
    return node;
  }

  const EXAMPLE = `BIO 101 - Cell Respiration (Ch 4)

Cellular respiration is the process cells use to turn glucose into usable energy.
ATP stands for adenosine triphosphate. It is the main energy currency of the cell.
The mitochondria is the organelle where most ATP is made.
Test on Monday, review this!!

Stages of respiration:
- Glycolysis
- Krebs cycle
- Electron transport chain

Glycolysis: splits glucose into two pyruvate molecules in the cytoplasm
Krebs cycle - a series of reactions in the mitochondrial matrix that release carbon dioxide
Fermentation happens when there is no oxygen available.

The process of making ATP using a proton gradient is called chemiosmosis.
Aerobic respiration produces about 36 ATP per glucose molecule.
Hans Krebs discovered the cycle in 1937 at the University of Sheffield.

What gas is released during the Krebs cycle?
Carbon dioxide

Q: Where does glycolysis happen? A: In the cytoplasm
Homework: read pages 40-52`;

  const KIND_LABEL = { definition: 'Definition', question: 'Question', list: 'List', cloze: 'Fill in the blank' };
  const KIND_PLURAL = { definition: 'Definitions', question: 'Questions', list: 'Lists', cloze: 'Fill in the blank' };
  const Q_LABEL = { mc: 'Multiple choice', tf: 'True or false', short: 'Short answer' };

  const ui = {
    stepNotes: $('step-notes'), stepReview: $('step-review'), stepDone: $('step-done'),
    notes: $('notes-input'), wordCount: $('word-count'), file: $('file-input'), example: $('example-btn'), clear: $('clear-btn'),
    title: $('title-input'), subject: $('subject-input'), subjectList: $('subject-list'),
    notesError: $('notes-error'), make: $('make-btn'),
    fromSummary: $('from-summary'), fromSummaryTitle: $('from-summary-title'),
    back: $('back-btn'), reviewSub: $('review-sub'),
    makeCards: $('make-cards'), makeQuiz: $('make-quiz'), makeSummary: $('make-summary'),
    cardsCount: $('make-cards-count'), quizCount: $('make-quiz-count'), summaryOpt: $('make-summary-opt'), summaryNote: $('make-summary-note'),
    tabs: { cards: $('tab-cards'), quiz: $('tab-quiz'), summary: $('tab-summary') },
    panels: { cards: $('panel-cards'), quiz: $('panel-quiz'), summary: $('panel-summary') },
    filters: $('kind-filters'), toggleAll: $('toggle-all-cards'), cardList: $('card-list'),
    quizList: $('quiz-list'), reshuffle: $('reshuffle-quiz'), summaryText: $('summary-input'),
    saveError: $('save-error'), save: $('save-btn'),
    doneTitle: $('done-title'), doneSub: $('done-sub'), doneLinks: $('done-links'), another: $('another-btn'),
  };

  // Current draft
  let cards = [];        // { front, back, kind, on, items?, heading?, sentence? }
  let questions = [];    // { type, prompt, ..., on }
  let quizDirty = false;
  let sourceSummary = null; // when started from an existing summary

  function showStep(name) {
    ui.stepNotes.hidden = name !== 'notes';
    ui.stepReview.hidden = name !== 'review';
    ui.stepDone.hidden = name !== 'done';
    window.scrollTo({ top: 0 });
  }

  /* ---------- Step 1 ---------- */
  function updateWordCount() {
    const words = (ui.notes.value.match(/\S+/g) || []).length;
    ui.wordCount.textContent = words ? plural(words, 'word') : '';
    ui.clear.hidden = words === 0;
    try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ notes: ui.notes.value, title: ui.title.value, subject: ui.subject.value })); } catch (e) { /* unavailable */ }
  }

  [ui.notes, ui.title, ui.subject].forEach((i) => i.addEventListener('input', updateWordCount));
  ui.notes.addEventListener('input', () => { ui.notesError.textContent = ''; });

  ui.example.addEventListener('click', () => {
    ui.notes.value = EXAMPLE;
    ui.title.value = 'Example: Cell Respiration';
    ui.subject.value = 'Biology';
    updateWordCount();
  });

  ui.clear.addEventListener('click', () => {
    if (ui.notes.value.length > 200 && !confirm('Clear your notes?')) return;
    ui.notes.value = '';
    updateWordCount();
    ui.notes.focus();
  });

  ui.file.addEventListener('change', () => {
    const file = ui.file.files[0];
    ui.file.value = '';
    if (!file) return;
    if (/\.(pdf|docx?|pages|rtf|pptx?|key)$/i.test(file.name)) {
      ui.notesError.textContent = "That kind of file can't be read here. Open it, select the text, copy it, and paste it into the box.";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      ui.notes.value = String(reader.result || '');
      if (!ui.title.value) ui.title.value = file.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' ');
      updateWordCount();
      ui.notesError.textContent = '';
    };
    reader.onerror = () => { ui.notesError.textContent = "That file couldn't be opened."; };
    reader.readAsText(file);
  });

  ui.make.addEventListener('click', () => {
    const text = ui.notes.value.trim();
    if (!text) { ui.notesError.textContent = 'Paste your notes in the box first.'; ui.notes.focus(); return; }

    const analysis = G.analyze(text);
    if (!analysis.cards.length) {
      ui.notesError.textContent = "Couldn't find anything to make cards from yet. Try notes with definitions (\"X is…\" or \"Term: meaning\"), questions and answers, or facts with names, dates and numbers. See the tips below.";
      return;
    }
    if (!ui.title.value.trim()) ui.title.value = analysis.title || suggestTitle(analysis);

    cards = analysis.cards.map((c) => ({ ...c, on: true }));
    questions = G.buildQuiz(cards).map((q) => ({ ...q, on: true }));
    quizDirty = false;
    ui.summaryText.value = sourceSummary ? sourceSummary.body : G.buildSummary(analysis);

    ui.makeCards.checked = true;
    ui.makeQuiz.checked = questions.length > 0;
    ui.makeQuiz.disabled = questions.length === 0;
    if (!sourceSummary) ui.makeSummary.checked = true;
    ui.saveError.textContent = '';

    renderFilters();
    renderCards();
    renderQuiz();
    renderCounts();
    selectTab('cards');
    showStep('review');
  });

  function suggestTitle(analysis) {
    const def = analysis.cards.find((c) => c.kind === 'definition');
    if (def) return `${def.front} notes`;
    return `Notes from ${new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}`;
  }

  /* ---------- Step 2 ---------- */
  ui.back.addEventListener('click', () => showStep('notes'));

  function selectTab(name) {
    if (name === 'quiz' && quizDirty) rebuildQuiz();
    Object.entries(ui.tabs).forEach(([k, t]) => t.setAttribute('aria-selected', String(k === name)));
    Object.entries(ui.panels).forEach(([k, p]) => { p.hidden = k !== name; });
  }
  Object.entries(ui.tabs).forEach(([k, t]) => t.addEventListener('click', () => selectTab(k)));

  function renderCounts() {
    const nCards = cards.filter((c) => c.on).length;
    const nQs = questions.filter((q) => q.on).length;
    ui.cardsCount.textContent = plural(nCards, 'card');
    ui.quizCount.textContent = questions.length ? plural(nQs, 'question') : 'Needs more definitions';
    ui.tabs.cards.textContent = `Flashcards (${nCards})`;
    ui.tabs.quiz.textContent = `Quiz (${nQs})`;
    const made = [ui.makeCards.checked && nCards && plural(nCards, 'flashcard'), ui.makeQuiz.checked && nQs && plural(nQs, 'quiz question'),
      ui.makeSummary.checked && 'a summary and podcast episode'].filter(Boolean);
    ui.reviewSub.textContent = made.length ? `From your notes: ${made.length > 1 ? `${made.slice(0, -1).join(', ')} and ${made[made.length - 1]}` : made[0]}.` : 'Choose at least one thing to create.';
    ui.save.disabled = made.length === 0;
    ui.toggleAll.textContent = cards.every((c) => c.on) ? 'Select none' : 'Select all';
  }

  [ui.makeCards, ui.makeQuiz, ui.makeSummary].forEach((c) => c.addEventListener('change', renderCounts));

  function renderFilters() {
    const kinds = [...new Set(cards.map((c) => c.kind))];
    ui.filters.replaceChildren(...kinds.map((k) => {
      const all = cards.filter((c) => c.kind === k);
      const on = all.every((c) => c.on);
      return h('button', { type: 'button', class: 'kind-chip', 'aria-pressed': String(on), onclick: () => {
        all.forEach((c) => { c.on = !on; });
        quizDirty = true;
        renderFilters(); renderCards(); renderCounts();
      } }, `${on ? '✓ ' : ''}${KIND_PLURAL[k]} (${all.length})`);
    }));
  }

  function autosize(t) { t.style.height = 'auto'; t.style.height = `${t.scrollHeight}px`; }

  function renderCards() {
    ui.cardList.replaceChildren(...cards.map((c, i) => {
      const front = h('textarea', { class: 'gen-front', rows: 1, 'aria-label': `Card ${i + 1} front` });
      front.value = c.front;
      const back = h('textarea', { class: 'gen-back', rows: 1, 'aria-label': `Card ${i + 1} back` });
      back.value = c.back;
      [front, back].forEach((t) => t.addEventListener('input', () => {
        c.front = front.value; c.back = back.value; quizDirty = true; autosize(t);
      }));
      const li = h('li', { class: `gen-item${c.on ? '' : ' is-off'}` },
        h('input', { type: 'checkbox', checked: c.on, 'aria-label': `Include card ${i + 1}`, onchange: (e) => {
          c.on = e.target.checked; li.classList.toggle('is-off', !c.on); quizDirty = true; renderFilters(); renderCounts();
        } }),
        h('div', { class: 'gen-fields' }, h('span', { class: 'kind', text: KIND_LABEL[c.kind] }), front, back),
      );
      return li;
    }));
    requestAnimationFrame(() => ui.cardList.querySelectorAll('textarea').forEach(autosize));
  }

  ui.toggleAll.addEventListener('click', () => {
    const allOn = cards.every((c) => c.on);
    cards.forEach((c) => { c.on = !allOn; });
    quizDirty = true;
    renderFilters(); renderCards(); renderCounts();
  });

  function rebuildQuiz() {
    const off = new Set(questions.filter((q) => !q.on).map((q) => q.prompt));
    const chosen = cards.filter((c) => c.on && c.front.trim() && c.back.trim()).map((c) => ({ ...c, front: c.front.trim(), back: c.back.trim() }));
    questions = G.buildQuiz(chosen).map((q) => ({ ...q, on: !off.has(q.prompt) }));
    quizDirty = false;
    ui.makeQuiz.disabled = questions.length === 0;
    if (!questions.length) ui.makeQuiz.checked = false;
    renderQuiz();
    renderCounts();
  }

  ui.reshuffle.addEventListener('click', () => { quizDirty = true; rebuildQuiz(); });

  function answerText(q) {
    if (q.type === 'mc') return q.options[q.answer];
    if (q.type === 'tf') return q.answer ? 'True' : 'False';
    return q.answers[0];
  }

  function renderQuiz() {
    if (!questions.length) {
      ui.quizList.replaceChildren(h('li', { class: 'help', text: 'There isn\'t enough here to write quiz questions. Quizzes need at least two definitions or some facts with names, dates or numbers.' }));
      return;
    }
    ui.quizList.replaceChildren(...questions.map((q, i) => {
      const li = h('li', { class: `gen-item${q.on ? '' : ' is-off'}` },
        h('input', { type: 'checkbox', checked: q.on, 'aria-label': `Include question ${i + 1}`, onchange: (e) => {
          q.on = e.target.checked; li.classList.toggle('is-off', !q.on); renderCounts();
        } }),
        h('div', { class: 'gen-fields' },
          h('span', { class: 'kind', text: Q_LABEL[q.type] }),
          h('p', { class: 'q-prompt', text: q.prompt }),
          q.type === 'mc' ? h('p', { class: 'q-answer' }, q.options.map((o, j) => [j ? ' · ' : '', j === q.answer ? h('strong', { text: `✓ ${o}` }) : o])) :
            h('p', { class: 'q-answer' }, 'Answer: ', h('strong', { text: answerText(q) })),
        ),
      );
      return li;
    }));
  }

  /* ---------- Save ---------- */
  function write(key, value) { localStorage.setItem(key, JSON.stringify(value)); }

  ui.save.addEventListener('click', () => {
    if (quizDirty) rebuildQuiz();
    const title = ui.title.value.trim() || 'My notes';
    const subject = ui.subject.value.trim();
    const now = new Date().toISOString();
    const chosenCards = cards.filter((c) => c.on && c.front.trim() && c.back.trim());
    const chosenQs = questions.filter((q) => q.on);
    const result = { deck: null, quiz: null, summary: null };

    // Snapshot so a storage failure halfway leaves nothing half-saved.
    const before = [FLASHCARD_KEY, QUIZ_KEY, SUMMARY_KEY].map((k) => [k, localStorage.getItem(k)]);
    try {
      if (ui.makeCards.checked && chosenCards.length) {
        const data = readJSON(FLASHCARD_KEY) || { decks: [], currentDeckId: null };
        const deck = { id: uid(), name: title, cards: chosenCards.map((c) => ({ id: uid(), front: c.front.trim(), back: c.back.trim(), known: false })) };
        data.decks.push(deck);
        data.currentDeckId = deck.id;
        write(FLASHCARD_KEY, data);
        result.deck = deck;
      }
      if (ui.makeQuiz.checked && chosenQs.length) {
        const data = readJSON(QUIZ_KEY) || { quizzes: [], history: {}, settings: { count: '10', shuffle: true } };
        const quiz = { id: uid(), title, questions: chosenQs.map(({ on, ...q }) => ({ id: uid(), explanation: '', ...q })) };
        data.quizzes.push(quiz);
        write(QUIZ_KEY, data);
        result.quiz = quiz;
      }
      const data = readJSON(SUMMARY_KEY) || { summaries: [] };
      if (sourceSummary) {
        const s = data.summaries.find((x) => x.id === sourceSummary.id);
        if (s) {
          if (result.deck) s.deckId = result.deck.id;
          if (result.quiz) s.quizId = result.quiz.id;
          s.updatedAt = now;
          result.summary = s;
          write(SUMMARY_KEY, data);
        }
      } else if (ui.makeSummary.checked) {
        const s = { id: uid(), title, subject, body: ui.summaryText.value, deckId: result.deck ? result.deck.id : null,
          quizId: result.quiz ? result.quiz.id : null, createdAt: now, updatedAt: now, reviewedAt: null };
        data.summaries.push(s);
        write(SUMMARY_KEY, data);
        result.summary = s;
      }
    } catch (e) {
      before.forEach(([k, v]) => { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e2) { /* ignore */ } });
      ui.saveError.textContent = "Your browser wouldn't save this (it may be out of storage space). Nothing was changed.";
      return;
    }

    try { sessionStorage.removeItem(DRAFT_KEY); } catch (e) { /* unavailable */ }
    showDone(title, result);
  });

  function link(icon, title, text, href) {
    return h('a', { class: 'next-card', href }, h('span', { class: 'next-icon', 'aria-hidden': 'true', text: icon }), h('strong', { text: title }), h('span', { text }));
  }

  function showDone(title, r) {
    ui.doneTitle.textContent = `"${title}" is ready`;
    const made = [r.deck && plural(r.deck.cards.length, 'flashcard'), r.quiz && plural(r.quiz.questions.length, 'quiz question'),
      r.summary && !sourceSummary && 'a summary'].filter(Boolean);
    ui.doneSub.textContent = `Created ${made.length > 1 ? `${made.slice(0, -1).join(', ')} and ${made[made.length - 1]}` : made[0]}. Here's a good order to study it in:`;
    const links = [];
    if (r.summary) links.push(link('📝', '1. Read the summary', 'Get the big picture first', `summaries.html#read/${r.summary.id}`));
    if (r.deck) links.push(link('🗂️', `${links.length + 1}. Drill the flashcards`, plural(r.deck.cards.length, 'card'), 'flashcards.html'));
    if (r.quiz) links.push(link('✅', `${links.length + 1}. Take the quiz`, plural(r.quiz.questions.length, 'question'), `quizzes.html#start/${r.quiz.id}`));
    if (r.summary) links.push(link('🎧', 'Listen on the go', 'Your podcast episode', `podcast.html#ep/${r.summary.id}`));
    if (r.deck || r.quiz) links.push(link('⏱️', 'A few days later: practice test', 'Timed, mixed with your other topics', 'tests.html'));
    ui.doneLinks.replaceChildren(...links);
    showStep('done');
  }

  ui.another.addEventListener('click', () => {
    sourceSummary = null;
    ui.fromSummary.hidden = true;
    ui.makeSummary.disabled = false;
    ui.summaryNote.textContent = 'Read it or listen to it';
    ui.tabs.summary.hidden = false;
    ui.notes.value = '';
    ui.title.value = '';
    ui.subject.value = '';
    history.replaceState(null, '', location.pathname);
    updateWordCount();
    showStep('notes');
  });

  $('to-top').addEventListener('click', (e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); });

  /* ---------- Start ---------- */
  function init() {
    const summaries = (readJSON(SUMMARY_KEY) || {}).summaries || [];
    const subjects = [...new Set(summaries.map((s) => (s.subject || '').trim()).filter(Boolean))].sort();
    ui.subjectList.replaceChildren(...subjects.map((s) => h('option', { value: s })));

    // create.html#summary/<id>: make cards and a quiz from an existing summary
    const m = location.hash.match(/^#summary\/(.+)$/);
    const fromSummary = m && summaries.find((s) => s.id === decodeURIComponent(m[1]));
    if (fromSummary) {
      sourceSummary = fromSummary;
      ui.notes.value = fromSummary.body;
      ui.title.value = fromSummary.title;
      ui.subject.value = fromSummary.subject || '';
      ui.fromSummary.hidden = false;
      ui.fromSummaryTitle.textContent = `"${fromSummary.title || 'Untitled summary'}"`;
      ui.makeSummary.checked = false;
      ui.makeSummary.disabled = true;
      ui.summaryNote.textContent = 'Already have it: linking to it';
      ui.tabs.summary.hidden = true;
    } else {
      try {
        const draft = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
        if (draft) { ui.notes.value = draft.notes || ''; ui.title.value = draft.title || ''; ui.subject.value = draft.subject || ''; }
      } catch (e) { /* unavailable */ }
    }
    updateWordCount();
  }

  init();
})();
