/* The Study Room: card generator
   Reads free-form notes and suggests flashcards. Runs entirely in the browser.

   It looks for:
   - Definitions:   "Term: definition", "Term - definition", "**Term** definition",
                    "X is/are …", "X refers to / means / stands for …", "… is called X"
   - Questions:     a line ending in "?" (or "Q: …") with the answer on the next line
   - Lists:         a heading ("Causes of WW1:") followed by 2–10 short bullet points
   - Key facts:     fill-in-the-blank cards that hide a term, a name, a date or a number

   Usage: CardGenerator.generate(text, { cloze: true }) -> [{ front, back, kind }]
   kind is one of: "definition", "question", "list", "cloze". */
(function (root) {
  'use strict';

  // Words that can't start a real "term" (so "It is important…" isn't a definition).
  const NOT_A_TERM = /^(it|its|it's|this|that|these|those|they|them|there|here|he|she|we|i|you|your|our|their|his|her|my|which|what|who|whom|whose|when|where|why|how|and|but|or|so|because|if|then|also|however|therefore|thus|one|some|many|most|each|every|all|both|such|another|other|first|second|third|next|finally|today|now|note|remember|everything|nothing|something|anything|everyone|someone|nobody|people|homework|class|lecture|exam|test|quiz)\b/i;
  // Predicates that describe a situation rather than define something.
  const NOT_A_DEFINITION = /^(not|very|also|so|too|really|quite|still|just|going|on|in|at|about|due|over|from|here|there|due|important|easy|hard|difficult|good|bad|great|fine|true|false|important|interesting|likely|unlikely|able|unable|done|next|why|because)\b/i;

  const ABBREVIATIONS = /\b(e\.g|i\.e|etc|vs|approx|cf|fig|no|dr|mr|mrs|ms|prof|st|jr|sr|inc|ltd|co|ca|al)\./gi;

  function normalize(s) {
    return String(s).toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, '').replace(/\s+/g, ' ').trim();
  }

  function wordCount(s) { return (String(s).match(/\S+/g) || []).length; }

  // Remove Markdown and list markers, keep the words.
  function clean(s) {
    return String(s)
      .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
      .replace(/(\*\*|__|==|`)/g, '')
      .replace(/(^|\W)[*_](\S(?:.*?\S)?)[*_](?=\W|$)/g, '$1$2')
      .replace(/^\s*#{1,6}\s+/, '')
      .replace(/^\s*>\s?/, '')
      .replace(/^\s*(?:[-*+•▪◦‣–]|\d+[.)]|[a-z][.)]|\(?[ivx]+\))\s+/i, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function tidyTerm(t) {
    return clean(t).replace(/^(the|a|an)\s+(?=\S+\s*$)/i, '').replace(/[\s:;,.\-–—=]+$/, '').trim();
  }

  function tidyBack(d) {
    let s = clean(d).replace(/^[\s:;,\-–—=>]+/, '').replace(/([^.])\.$/, '$1').trim();
    if (s) s = s.charAt(0).toUpperCase() + s.slice(1);
    return s;
  }

  // "mitochondria" -> "Mitochondria", but leave "pH", "mRNA", "iPad" alone.
  const capTerm = (t) => (/^[\p{Ll}][\p{Ll}\s'-]*$/u.test(t) ? t.charAt(0).toUpperCase() + t.slice(1) : t);

  function validTerm(t) {
    if (!t || t.length > 70 || !/\p{L}/u.test(t)) return false;
    const words = wordCount(t);
    if (words > 7) return false;
    if (NOT_A_TERM.test(t)) return false;
    if (/[.!?]$/.test(t)) return false;
    if (/\b(of|in|on|at|to|for|with|and|or|the|a|an|by|from|is|are|was|were)$/i.test(t)) return false;
    if (/^\d+([.,:]\d+)*$/.test(t)) return false;
    return true;
  }

  function validDefinition(d) {
    const words = wordCount(d);
    return words >= 2 && d.length <= 500;
  }

  // Split a paragraph into sentences without breaking on "e.g." or "3.5".
  function sentences(text) {
    const protectedText = String(text)
      .replace(ABBREVIATIONS, (m) => m.replace(/\./g, '\u0001'))
      .replace(/(\d)\.(\d)/g, '$1\u0001$2');
    const parts = protectedText.match(/[^.!?]+(?:[.!?]+["')\]]*|$)/g) || [protectedText];
    return parts.map((p) => p.replace(/\u0001/g, '.').trim()).filter(Boolean);
  }

  /* ---------- Pattern matchers (return {front, back} or null) ---------- */

  // "**Term** something" at the start of a line (bold = the author marked a term).
  function boldTerm(rawLine) {
    const line = rawLine.replace(/^\s*(?:[-*+•]|\d+[.)])\s+/, '');
    const m = line.match(/^\*\*(.+?)\*\*\s*(?:[:\-–—=]+\s*)?(.+)$/) || line.match(/^__(.+?)__\s*(?:[:\-–—=]+\s*)?(.+)$/);
    if (!m) return null;
    const term = tidyTerm(m[1]);
    const back = tidyBack(m[2].replace(/^(is|are|refers to|means)\s+/i, ''));
    return validTerm(term) && validDefinition(back) ? { front: term, back } : null;
  }

  // "Term: definition", "Term - definition", "Term — definition", "Term = definition", "Term<TAB>definition"
  function separated(line) {
    const m = line.match(/^(.{1,70}?)(?:\s*:\s+|\s*\t+\s*|\s+[-=]\s+|\s*[–—]\s*|\s*=>\s*|\s*->\s*)(.+)$/);
    if (!m) return null;
    const term = tidyTerm(m[1]);
    const back = tidyBack(m[2]);
    if (/^https?$/i.test(term)) return null;
    return validTerm(term) && validDefinition(back) ? { front: term, back } : null;
  }

  // "… is called X" / "… is known as X"  -> front X, back "…"
  function calledPattern(s) {
    const m = s.match(/^(.{12,}?)\s+(?:is|are|was|were)\s+(?:called|known as|termed|referred to as|named)\s+(.{2,70}?)[.!]?$/i);
    if (!m) return null;
    const term = tidyTerm(m[2]);
    const back = tidyBack(m[1]);
    return validTerm(term) && validDefinition(back) && !NOT_A_TERM.test(back) ? { front: term, back } : null;
  }

  // "X refers to …", "X means …", "X stands for …", "X is defined as …"
  function verbPattern(s) {
    const m = s.match(/^(.{2,70}?)\s+(refers? to|means|is defined as|are defined as|is known as|are known as|stands for|is a term for|is the term for|describes|is when|occurs when|happens when)\s+(.+?)[.!]?$/i);
    if (!m) return null;
    const term = tidyTerm(m[1]);
    let back = m[3];
    if (/^(is when|occurs when|happens when)$/i.test(m[2])) back = `When ${back}`;
    if (/^stands for$/i.test(m[2])) back = `Stands for ${back}`;
    back = tidyBack(back);
    return validTerm(term) && validDefinition(back) ? { front: term, back } : null;
  }

  // "X is (a/an/the) …" / "X are …"
  function isPattern(s) {
    const m = s.match(/^(.{2,70}?)\s+(?:is|are)\s+(?!not\b)(.+?)[.!]?$/i);
    if (!m) return null;
    const term = tidyTerm(m[1]);
    const back = tidyBack(m[2]);
    if (!validTerm(term) || NOT_A_DEFINITION.test(m[2].trim())) return null;
    if (wordCount(back) < 4) return null; // "The test is on Monday" isn't a definition
    // A definition usually starts with an article, a noun phrase, or "the process/when/where…"
    if (!/^(a|an|the|one|any|when|where|how|what|used|made|found|responsible|caused|composed|formed|known|considered|defined|located|part|type|kind|form|process|study|ability|amount|measure|rate|tendency|set|group|series|state|condition|movement|transfer|change|structure|unit|number|science|theory|idea|principle|law|rule|method|way|period|organelle|molecule|cell|substance|compound|protein|enzyme|system|organ|tissue|force|energy|event|war|treaty|document|person|place|word|phrase|term)\b/i.test(back)) {
      // Accept other shapes only when the term looks like a proper term (capitalised or short).
      if (!(wordCount(term) <= 3 && /^[A-Z]/.test(term) && wordCount(back) >= 5)) return null;
    }
    return { front: term, back };
  }

  function definitionFromSentence(s) {
    return calledPattern(s) || verbPattern(s) || isPattern(s);
  }

  function isHeadingLine(raw, text) {
    if (/^\s*#{1,6}\s+\S/.test(raw)) return true;
    if (/:\s*$/.test(text) && !/:.+:/.test(text) && wordCount(text) <= 9) return true;
    const letters = text.replace(/[^\p{L}]/gu, '');
    if (letters.length >= 3 && letters === letters.toUpperCase() && wordCount(text) <= 7 && !/[.!?]$/.test(text)) return true;
    return false;
  }

  const isBullet = (raw) => /^\s*(?:[-*+•▪◦‣–]|\d+[.)]|[a-z][.)])\s+\S/i.test(raw);

  /* ---------- Fill in the blank ---------- */
  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  // Reminders and admin notes ("test is on Monday", "homework due Friday") aren't study facts.
  const ADMIN = /\b(test|exam|quiz|midterm|final|homework|assignment|due|deadline|lecture|class|office hours|review this|remember to|don'?t forget|study for|read pages?|bring)\b|!!/i;
  const NOT_A_NAME = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday|January|February|March|April|May|June|July|August|September|October|November|December|Chapter|Ch|Page|Section|Unit|Lesson|Figure|Table)$/;

  function makeCloze(sentence, knownTerms) {
    const s = sentence.trim();
    const words = wordCount(s);
    if (words < 6 || words > 40 || /\?$/.test(s) || ADMIN.test(s)) return null;

    // 1. A term you've already defined, used in another sentence.
    for (const t of knownTerms) {
      if (wordCount(t) > 5 || t.length < 3) continue;
      const re = new RegExp(`(^|[^\\p{L}\\p{N}])(${escapeRe(t)})(?=[^\\p{L}\\p{N}]|$)`, 'iu');
      const m = s.match(re);
      if (m && normalize(s) !== normalize(t)) {
        const start = m.index + m[1].length;
        return { front: s.slice(0, start) + '_____' + s.slice(start + m[2].length), back: m[2] };
      }
    }

    // 2. A year or a number with what it counts ("46 chromosomes", "1914", "70%").
    const num = s.match(/\b(1[0-9]{3}|20[0-9]{2})\b/) || s.match(/\b\d+(?:[.,]\d+)?\s?(?:%|percent|degrees|°[CF]?|km|m|cm|mm|kg|g|mg|l|ml|years?|days?|hours?|minutes?|seconds?|million|billion|thousand|[a-z]+s)\b/i);
    if (num && !/^\d+[.)]/.test(s)) {
      return { front: s.slice(0, num.index) + '_____' + s.slice(num.index + num[0].length), back: num[0] };
    }

    // 3. A capitalised name in the middle of the sentence ("Hermann Ebbinghaus", "Treaty of Versailles").
    const nameRe = /\b([A-Z][\p{L}'’-]+(?:\s+(?:of|the|de|von|van|and)\s+[A-Z][\p{L}'’-]+|\s+[A-Z][\p{L}'’-]+)*)/gu;
    let m;
    while ((m = nameRe.exec(s))) {
      if (m.index === 0) continue; // sentence-initial capitals aren't necessarily names
      const name = m[1];
      if (/^(I|I'm|I've|I'll|A|An|The)$/.test(name) || NOT_A_NAME.test(name)) continue;
      if (wordCount(name) === 1 && name.length < 4) continue;
      return { front: s.slice(0, m.index) + '_____' + s.slice(m.index + name.length), back: name };
    }
    return null;
  }

  /* ---------- Main ---------- */
  function analyze(text, options = {}) {
    const opts = { cloze: true, ...options };
    const rawLines = String(text || '').replace(/\r\n?/g, '\n').split('\n');
    const lines = rawLines.map((raw) => ({ raw, text: clean(raw) }));
    const cards = [];
    const seenFronts = new Set();
    const usedLines = new Set();
    const leftovers = []; // sentences that might make fill-in-the-blank cards
    let inCode = false;
    const firstLine = lines.findIndex((l) => l.text);

    const add = (card, kind, order, extra = {}) => {
      if (!card || !card.front || !card.back) return false;
      const key = normalize(card.front);
      if (!key || seenFronts.has(key) || normalize(card.back) === key) return false;
      seenFronts.add(key);
      const front = kind === 'definition' ? capTerm(card.front.trim()) : card.front.trim();
      cards.push({ front, back: card.back.trim(), kind, order, ...extra });
      return true;
    };
    let title = '';

    for (let i = 0; i < lines.length; i++) {
      const { raw, text: line } = lines[i];
      if (/^\s*```/.test(raw)) { inCode = !inCode; continue; }
      if (inCode || !line || usedLines.has(i)) continue;
      const order = i * 100;

      // A short opening line with no full stop ("BIO 101 - Cell Respiration") is a title.
      if (i === firstLine && !/[.!?]$/.test(line) && wordCount(line) <= 10 && lines.filter((l) => l.text).length > 2) { title = line.replace(/:\s*$/, ''); continue; }

      // Headings: maybe a list card, never a definition themselves.
      if (isHeadingLine(raw, line)) {
        const heading = line.replace(/:\s*$/, '').trim();
        const items = [];
        let j = i + 1;
        while (j < lines.length && !lines[j].text) j++;
        for (; j < lines.length && isBullet(lines[j].raw); j++) items.push(lines[j].text);
        const allShort = items.every((it) => wordCount(it) <= 14);
        const definitional = items.filter((it) => separated(it) || boldTerm(it)).length;
        if (items.length >= 2 && items.length <= 10 && allShort && definitional < items.length / 2 && validDefinition(heading + ' x')) {
          add({ front: `${heading}: name all ${items.length}`, back: items.map((it) => `• ${it.replace(/[.;,]$/, '')}`).join('\n') }, 'list', order,
            { heading, items: items.map((it) => it.replace(/[.;,]$/, '')) });
        }
        continue;
      }

      // Questions: "Q: …" / "…?" followed by the answer.
      const qPrefixed = line.match(/^q(?:uestion)?\s*\d*\s*[:.)-]\s*(.+)$/i);
      if (qPrefixed || (/\?$/.test(line) && wordCount(line) >= 3)) {
        let question = qPrefixed ? qPrefixed[1] : line;
        let answer = '';
        const inline = question.match(/^(.+?\?)\s*(?:a(?:nswer)?\s*[:.)-]\s*)?(.+)$/i);
        if (qPrefixed && inline && inline[2]) { question = inline[1]; answer = inline[2]; }
        if (!answer) {
          let j = i + 1;
          while (j < lines.length && !lines[j].text && j - i < 3) j++;
          const next = lines[j];
          if (next && next.text && !/\?$/.test(next.text) && !isHeadingLine(next.raw, next.text)) {
            answer = next.text.replace(/^a(?:nswer)?\s*[:.)-]\s*/i, '');
            usedLines.add(j);
          }
        }
        if (answer && add({ front: question.trim(), back: tidyBack(answer) }, 'question', order)) continue;
      }

      // Definitions written on one line.
      const lineCard = boldTerm(raw) || (wordCount(line) <= 80 ? separated(line) : null);
      if (lineCard) {
        add(lineCard, 'definition', order);
        continue;
      }

      // Otherwise look at each sentence.
      sentences(line).forEach((s, k) => {
        const def = definitionFromSentence(s);
        if (def && add(def, 'definition', order + k)) return;
        leftovers.push({ s, order: order + k });
      });
    }

    if (opts.cloze) {
      const known = cards.filter((c) => c.kind === 'definition').map((c) => c.front).sort((a, b) => b.length - a.length);
      leftovers.forEach(({ s, order }) => {
        const c = makeCloze(s, known);
        if (c) add(c, 'cloze', order + 50, { sentence: s });
      });
    }

    cards.sort((a, b) => a.order - b.order);
    const facts = cards.filter((c) => c.kind === 'cloze').map((c) => c.sentence);
    const factSet = new Set(facts);
    const overview = leftovers
      .map((l) => l.s)
      .filter((x) => !factSet.has(x) && wordCount(x) >= 6 && !ADMIN.test(x) && !/\?$/.test(x)
        && !/^(it|its|this|that|these|those|they|he|she|we|you|i|also|so|and|but)\b/i.test(x)
        && !/\bimportant to (know|remember|learn|study)\b/i.test(x))
      .slice(0, 3);
    return { cards, facts, overview, title };
  }

  function generate(text, options = {}) {
    return analyze(text, options).cards.map(({ front, back, kind }) => ({ front, back, kind }));
  }

  /* ---------- Quiz questions from cards ---------- */
  function shuffled(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }

  // Up to `n` distractors from `pool`, skipping anything that matches the right answer.
  function distractors(pool, correct, n = 3) {
    const seen = new Set([normalize(correct)]);
    const out = [];
    shuffled(pool).forEach((p) => {
      const k = normalize(p);
      if (out.length < n && k && !seen.has(k)) { seen.add(k); out.push(p); }
    });
    return out;
  }

  function multipleChoice(prompt, correct, wrong, explanation = '') {
    const options = shuffled([correct, ...wrong]);
    return { type: 'mc', prompt, options, answer: options.indexOf(correct), explanation };
  }

  function buildQuiz(cards, maxQuestions = 30) {
    const defs = cards.filter((c) => c.kind === 'definition');
    const defBacks = defs.map((c) => c.back);
    const terms = defs.map((c) => c.front);
    const questions = [];

    cards.forEach((c, idx) => {
      if (c.kind === 'definition') {
        const others = defBacks.filter((b) => b !== c.back);
        const n = defs.indexOf(c);
        if (others.length && n % 3 === 2) {
          // True/false: right definition, or a different term's definition.
          const truth = Math.random() < 0.5;
          const shown = truth ? c.back : distractors(others, c.back, 1)[0];
          questions.push({ type: 'tf', prompt: `True or false?\n${c.front}: ${shown.charAt(0).toLowerCase()}${shown.slice(1)}`, answer: truth,
            explanation: `${c.front}: ${c.back}` });
        } else if (others.length && n % 3 === 1 && terms.length >= 2) {
          // Reverse: show the definition, pick the term.
          questions.push(multipleChoice(`Which term matches this description? "${c.back.replace(/[.]$/, '')}"`, c.front,
            distractors(terms.filter((t) => t !== c.front), c.front), `${c.front}: ${c.back}`));
        } else if (others.length) {
          questions.push(multipleChoice(`What does "${c.front}" mean?`, c.back, distractors(others, c.back), ''));
        }
      } else if (c.kind === 'cloze') {
        const answers = [c.back];
        const bare = c.back.match(/^\d+(?:[.,]\d+)?/);
        if (bare && bare[0] !== c.back) answers.push(bare[0]);
        questions.push({ type: 'short', prompt: `Fill in the blank: ${c.front}`, answers, explanation: c.sentence || '' });
      } else if (c.kind === 'question') {
        if (wordCount(c.back) <= 4) {
          const full = c.back.replace(/[.]$/, '');
          const answers = [full];
          let core = full;
          while (/^(in|on|at|by|to|from|into|the|a|an)\s+\S/i.test(core)) { core = core.replace(/^\S+\s+/, ''); answers.push(core); }
          questions.push({ type: 'short', prompt: c.front, answers: [...new Set(answers)], explanation: '' });
        } else {
          const pool = cards.filter((o) => o !== c && (o.kind === 'question' || o.kind === 'definition')).map((o) => o.back);
          if (pool.length >= 2) questions.push(multipleChoice(c.front, c.back, distractors(pool, c.back), ''));
        }
      } else if (c.kind === 'list' && c.items) {
        // Compare loosely ("Alliance" vs "Alliances") so no wrong answer is secretly right.
        const similar = (a, b) => {
          const x = normalize(a); const y = normalize(b);
          return x === y || ((x.startsWith(y) || y.startsWith(x)) && Math.abs(x.length - y.length) <= 3);
        };
        const pool = [...terms, ...cards.filter((o) => o.kind === 'list' && o !== c).flatMap((o) => o.items || [])]
          .filter((t) => !c.items.some((it) => similar(it, t)));
        if (pool.length >= 2) {
          const pick = c.items[idx % c.items.length];
          questions.push(multipleChoice(`Which of these is one of the ${c.heading.replace(/\s*\(.*\)$/, '')}?`, pick, distractors(pool, pick),
            `${c.heading}: ${c.items.join(', ')}`));
        }
      }
    });
    return questions.slice(0, maxQuestions);
  }

  /* ---------- A summary from the notes ---------- */
  function buildSummary(analysis) {
    const { cards, facts, overview } = analysis;
    const defs = cards.filter((c) => c.kind === 'definition');
    const lists = cards.filter((c) => c.kind === 'list');
    const qs = cards.filter((c) => c.kind === 'question');
    const parts = [];
    const topics = [...defs.map((c) => c.front), ...lists.map((l) => l.heading.replace(/\s*\(.*\)$/, '').toLowerCase())].slice(0, 5);
    const joinList = (xs) => (xs.length > 1 ? `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}` : xs[0]);
    if (overview.length) parts.push('## Big picture', '', overview.join(' '), '');
    else if (topics.length) parts.push('## Big picture', '', `These notes cover ${joinList(topics)}.`, '');
    if (defs.length) parts.push('## Key terms', '', ...defs.map((c) => `- **${c.front}**: ${c.back}`), '');
    if (facts.length) parts.push('## Key facts', '', ...facts.map((f) => `- ${f}`), '');
    lists.forEach((l) => parts.push(`## ${l.heading}`, '', ...l.items.map((it, i) => `${i + 1}. ${it}`), ''));
    if (qs.length) parts.push('## Questions to ask yourself', '', ...qs.map((q) => `- ${q.front} *${q.back}*`), '');
    if (defs.length) {
      const top = defs.slice(0, 3).map((d) => d.front);
      const list = joinList(top);
      parts.push('## Takeaways', '', `> If you remember nothing else, make sure you can explain ${list} in your own words.`, '');
    }
    return parts.join('\n').trim() + '\n';
  }

  const api = { generate, analyze, buildQuiz, buildSummary, normalize };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CardGenerator = api;
})(typeof window !== 'undefined' ? window : globalThis);
